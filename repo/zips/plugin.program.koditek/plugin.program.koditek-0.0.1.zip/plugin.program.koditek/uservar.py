import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/SubTek/koditek/master/builds/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url = 'https://raw.githubusercontent.com/SubTek/koditek/master/builds/notify.txt'

'''#####-----Excludes-----#####'''
excludes = ['plugin.video.whatever']